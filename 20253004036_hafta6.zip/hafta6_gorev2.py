# Ad Soyad: Enes Sunar
# Öğrenci Numarası: 20253004036
# Tarih: 01.11.2026
# Açıklama: Metindeki harf, sesli/sessiz, rakam ve kelime sayısını bulup palindrom kontrolü yapar.

cumle = input("Cümle: ")

harf_sayisi = 0
sesli_sayisi = 0
sessiz_sayisi = 0
rakam_sayisi = 0
kelime_sayisi = 0

sesliler = "aeıioöuüAEIİOÖUÜ"
harfler_sadece_kucuk = ""
ters_cumle = ""

kelime_icindeyiz = False

for karakter in cumle:
    ters_cumle = karakter + ters_cumle
    
    if karakter.isalpha():
        harf_sayisi += 1
        harfler_sadece_kucuk += karakter.lower()
        if karakter in sesliler:
            sesli_sayisi += 1
        else:
            sessiz_sayisi += 1
        kelime_icindeyiz = True
    elif karakter.isdigit():
        rakam_sayisi += 1
        kelime_icindeyiz = True
    else:
        if kelime_icindeyiz:
            kelime_sayisi += 1
            kelime_icindeyiz = False

if kelime_icindeyiz:
    kelime_sayisi += 1

print(f"Harf: {harf_sayisi} Sesli: {sesli_sayisi} Sessiz: {sessiz_sayisi}")
print(f"Rakam: {rakam_sayisi} Kelime: {kelime_sayisi}")
print(f"Ters: {ters_cumle}")

ters_sadece_harf = ""
for h in harfler_sadece_kucuk:
    ters_sadece_harf = h + ters_sadece_harf

if harfler_sadece_kucuk == ters_sadece_harf and harfler_sadece_kucuk != "":
    print("Palindrom")
elif harfler_sadece_kucuk != "":
    print("Palindrom değil")
