# Ad Soyad: Enes Sunar
# Öğrenci Numarası: 20253004036
# Tarih: 01.11.2026
# Açıklama: T.C. Kimlik Numarasının doğrulamasını yapar.

tc_no = input("T.C. kimlik no: ")

if len(tc_no) == 11 and tc_no.isdigit() and tc_no[0] != "0":
    tek_toplam = 0 
    cift_toplam = 0 
    
    for i in range(9):
        rakam = int(tc_no[i])
        if i % 2 == 0:
            tek_toplam += rakam
        else:
            cift_toplam += rakam
            
    h10 = ((tek_toplam * 7) - cift_toplam) % 10
    h11 = (tek_toplam + cift_toplam + h10) % 10
    
    gercek_10 = int(tc_no[9])
    gercek_11 = int(tc_no[10])
    
    if h10 == gercek_10 and h11 == gercek_11:
        print(f"Tek: {tek_toplam} Çift: {cift_toplam} 10. hane: {h10} 11. hane: {h11} -> GEÇERLİ")
    else:
        print("-> GEÇERSİZ")
else:
    print("-> GEÇERSİZ")
