# Ad Soyad: Enes Sunar
# Öğrenci Numarası: 20253004036
# Tarih: 01.11.2026
# Açıklama: Adam asmaca oyunu.

gizli_kelime = "KOŞUL"
tahminler = ""
hata_sayisi = 0
maks_hata = 6

while hata_sayisi < maks_hata:
    gosterilecek_kelime = ""
    kelime_tamamlandi = True
    
    for harf in gizli_kelime:
        if harf in tahminler:
            gosterilecek_kelime += harf + " "
        else:
            gosterilecek_kelime += "_ "
            kelime_tamamlandi = False
            
    if kelime_tamamlandi:
        print(f"{gizli_kelime}")
        print(f"(hata: {hata_sayisi}/{maks_hata}) Kazandınız!")
        break
        
    print(gosterilecek_kelime.strip())
    print(f"(hata: {hata_sayisi}/{maks_hata})")
    
    giris = input("Harf: ").strip()
    
    if len(giris) != 1 or not giris.isalpha():
        continue
        
    giris = "I" if giris == "i" else giris.upper()
        
    if giris in tahminler:
        print("Bu harfi zaten denediniz.")
        continue
        
    tahminler += giris
    
    if giris not in gizli_kelime:
        hata_sayisi += 1
else:
    print(f"Kaybettiniz! Kelime: {gizli_kelime}")
