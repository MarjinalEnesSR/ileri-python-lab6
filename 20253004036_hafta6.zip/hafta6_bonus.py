# Ad Soyad: Enes Sunar
# Öğrenci Numarası: 20253004036
# Tarih: 01.11.2026
# Açıklama: Luhn algoritması kontrol hanesi bulucu.

ilk_15_hane = "453914880343646"

for denenen_hane in range(10):
    tam_numara = ilk_15_hane + str(denenen_hane)
    toplam = 0
    
    for i in range(16):
        rakam = int(tam_numara[i])
        
        if i % 2 == 0:
            rakam *= 2
            if rakam > 9:
                rakam -= 9
                
        toplam += rakam
        
    if toplam % 10 == 0:
        print(f"Doğru kontrol hanesi (Bonus): {denenen_hane}")
        break
