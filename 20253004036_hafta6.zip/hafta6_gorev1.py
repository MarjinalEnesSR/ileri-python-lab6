# Ad Soyad: Enes Sunar
# Öğrenci Numarası: 20253004036
# Tarih: 01.11.2026
# Açıklama: Üçgen analizörü; kenarları alır, türü, alanı, çevreyi ve en büyük açıyı hesaplar.

import math

a_giris = float(input("a: "))
b_giris = float(input("b: "))
c_giris = float(input("c: "))

if a_giris <= 0 or b_giris <= 0 or c_giris <= 0:
    print("Kenarlar pozitif olmalıdır!")
elif (a_giris + b_giris <= c_giris) or (a_giris + c_giris <= b_giris) or (b_giris + c_giris <= a_giris):
    print("Bu kenarlarla bir üçgen çizilemez (Üçgen eşitsizliği sağlanmıyor)!")
else:
    if a_giris >= b_giris and a_giris >= c_giris:
        a_max, b_diger, c_diger = a_giris, b_giris, c_giris
    elif b_giris >= a_giris and b_giris >= c_giris:
        a_max, b_diger, c_diger = b_giris, a_giris, c_giris
    else:
        a_max, b_diger, c_diger = c_giris, a_giris, b_giris

    if a_giris == b_giris == c_giris:
        tur = "Eşkenar"
    elif a_giris == b_giris or a_giris == c_giris or b_giris == c_giris:
        tur = "İkizkenar"
    else:
        tur = "Çeşitkenar"

    cos_alfa = (b_diger**2 + c_diger**2 - a_max**2) / (2 * b_diger * c_diger)
    aci_radyan = math.acos(cos_alfa)
    aci_derece = math.degrees(aci_radyan)

    if math.isclose(aci_derece, 90, abs_tol=1e-5):
        aci_turu = "Dik açılı"
    elif aci_derece < 90:
        aci_turu = "Dar açılı"
    else:
        aci_turu = "Geniş açılı"

    u = (a_giris + b_giris + c_giris) / 2
    alan = math.sqrt(u * (u - a_giris) * (u - b_giris) * (u - c_giris))
    cevre = a_giris + b_giris + c_giris

    print(f"Tür: {tur}, {aci_turu}")
    print(f"Çevre: {cevre:.2f} Alan: {alan:.2f} En büyük açı: {aci_derece:.2f}°")
