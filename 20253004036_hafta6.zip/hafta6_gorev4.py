# Ad Soyad: Enes Sunar
# Öğrenci Numarası: 20253004036
# Tarih: 01.11.2026
# Açıklama: Collatz dizilerini hesaplar ve en uzun zinciri bulur.

n_ilk = int(input("n: "))

n = n_ilk
adim = 0
en_yuksek = n

while n != 1:
    n = n // 2 if n % 2 == 0 else 3 * n + 1
    if n > en_yuksek:
        en_yuksek = n
    adim += 1

print(f"{n_ilk} -> 1: {adim} adım, en yüksek değer {en_yuksek}")

sinir = int(input("Üst sınır: "))

en_uzun_adim = 0
en_uzun_baslangic = 1

for i in range(1, sinir + 1):
    mevcut_sayi = i
    mevcut_adim = 0
    while mevcut_sayi != 1:
        mevcut_sayi = mevcut_sayi // 2 if mevcut_sayi % 2 == 0 else 3 * mevcut_sayi + 1
        mevcut_adim += 1
        
    if mevcut_adim > en_uzun_adim:
        en_uzun_adim = mevcut_adim
        en_uzun_baslangic = i

print(f"1-{sinir} arasında en uzun zincir: {en_uzun_baslangic} ({en_uzun_adim} adım)")
